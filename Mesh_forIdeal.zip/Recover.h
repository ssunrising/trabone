void Recover(int ***type, int i, int j, int k, int *m_iSize);
int RecoverConnection(int ***type, int ***matrix, int i, int j, int k);
int PrimaryRecover(int ***type, int ***matrix, int i, int j, int k, int l);
