#define INF		999

void Final_Type(int ***matrix, int ***temp, int ***type, int i, int j, int k);
int Is_N34(int ***type, int i, int j, int k);
void Is_SCType(int ***type, int i, int j, int k);
int Distance(int i, int j, int k, int ii, int jj, int kk);

