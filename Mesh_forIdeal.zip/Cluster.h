int labelmax(int *label_nums, int num);
int neighbormin(int *neighbor);
int hoshen_kopelman (int ***matrix, int *size, BOOL m_bDebugmode);
int HKcluster4S (int ***matrix, int *size);

//3-1-2006
int hoshen_kopelman2 (int ***matrix, int *size);
int labelmax2(int *label_nums, int num, int labelmax);
int neighbormin2(int *neighbor);

