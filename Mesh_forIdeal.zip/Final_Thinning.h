int Is_cond4(int ***matrix, int ***temp, int i, int j, int k, int thr);
int Is_cond5(int ***matrix, int ***temp, int i, int j, int k, int thr);
int Is_cond6(int ***matrix, int ***temp, int i, int j, int k, int thr);
int Is_cond3(int ***matrix, int ***temp, int i, int j, int k, int thr);
int Is_single_26(int ***temp);

int thick(int ***temp, int thr);
