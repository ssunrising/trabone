int set1(int ***matrix, int i, int j, int k, int thr);
int set2(int ***matrix, int i, int j, int k, int thr);
int set3(int ***matrix, int i, int j, int k, int thr);
int Shape_Point(int ***matrix, int i, int j, int k, int thr);