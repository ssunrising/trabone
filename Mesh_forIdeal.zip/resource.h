//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Display.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DISPLATYPE                  129
#define IDD_FORM_COMMAND                130
#define IDD_CLASSIFY_COLOR              131
#define IDD_RESOLUTION                  132
#define IDD_TRABECULAE                  133
#define IDD_MORPH                       134
#define IDC_LOAD                        1000
#define IDC_THINNING                    1001
#define IDC_RECORD                      1002
#define IDC_CLASSIFY                    1003
#define IDC_RECORD_CLASSIFY             1004
#define IDC_DISPLAYSIZE                 1005
#define IDC_DISPLAY                     1006
#define IDC_ARCTHINNING                 1007
#define IDC_RECOVER                     1008
#define IDC_RECOVER2                    1009
#define IDC_RECOVER3                    1010
#define IDC_ARC_CLASSIFY                1011
#define IDC_SURFACE_INNER               1025
#define IDC_SURFACE_EDGE                1026
#define IDC_SURFACE_SURFACE             1027
#define IDC_IS                          1028
#define IDC_SE                          1029
#define IDC_PRIMARY                     1029
#define IDC_SS                          1030
#define IDC_FINAL                       1030
#define IDC_SURFACE_ARC                 1031
#define IDC_DEBUGSTART                  1031
#define IDC_SA                          1032
#define IDC_DEBUGEND                    1032
#define IDC_ARC_INNER                   1033
#define IDC_STATIC_DEBUG                1033
#define IDC_AI                          1034
#define IDC_EDIT1                       1034
#define IDC_ARCPRIMARY                  1034
#define IDC_ARC_END                     1035
#define IDC_CLUSTER                     1035
#define IDC_EDIT2                       1035
#define IDC_AE                          1036
#define IDC_PLATECLUSTER                1036
#define IDC_EDIT3                       1036
#define IDC_ARC_ARC                     1037
#define IDC_DECREASE                    1037
#define IDC_AA                          1038
#define IDC_INCREASE                    1038
#define IDC_ISOLATED_POINT              1039
#define IDC_TRANUMBER                   1039
#define IDC_IP                          1040
#define IDC_STATIC_MORPH                1040
#define IDC_ARCFINAL                    1040
#define IDC_BK                          1041
#define IDC_STEPDECREASE                1041
#define IDC_BACKGROUND                  1042
#define IDC_STEPINCREASE                1042
#define IDC_EG                          1043
#define IDC_STEPNUMBER                  1043
#define IDC_EDGE                        1044
#define ID_IMAGE_SMOOTH                 32771
#define ID_IMAGE_CULL                   32772
#define ID_IMAGE_COLOR                  32773
#define ID_IMAGE_ENLARGE                32776
#define ID_IMAGE_SHRINK                 32777
#define ID_BUTTON32780                  32780
#define ID_TOOL_TRASEP                  32781
#define ID_TOOL_PARAMETER               32782
#define ID_TOOL_MORPH                   32783
#define ID_TOOL_SAVEBINARY              32784
#define ID_TOOL_BKLDATA                 32785
#define ID_TOOL_STRESS                  32786
#define ID_TOOL_BINARY                  32787
#define ID_TOOL_PFCAL                   32788
#define IDC_TOOL_MULTISELECT            32789
#define IDC_TOOL_MESH                   32790

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32791
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
