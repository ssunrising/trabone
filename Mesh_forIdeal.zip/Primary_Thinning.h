//#define MAXNUM	999;

int Is_sopen_pt(int ***matrix, int i, int j, int k, int thr);
int Is_eopen_pt(int ***matrix, int i, int j, int k, int thr);
int Is_vopen_pt(int ***matrix, int i, int j, int k, int thr);
