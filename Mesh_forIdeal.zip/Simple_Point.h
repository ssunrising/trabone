void axis_k_90(int ***temp);
void axis_j_90(int ***temp);
void axis_i_90(int ***temp);

int Simple_Point(int ***matrix, int ***temp, int i, int j, int k);	//non-simle point return 1

